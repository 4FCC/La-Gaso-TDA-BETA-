﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//  Names spaces a utilizar
using Class1_Reabastecimiento_de_gasolina_a_depósitos;




// ---------- GASOLINERAS EL FERNANDO (Codigo Fuente)----------



try
{

    // OPCIONES DE ADMINISTRADOR

    // Bienvenido
    Console.WriteLine("Bienvenido a * Gasolineras Fernando * ");

    bool Reiniciar = false;
    Objetos oObjetos = new Objetos();

    do
    {

        // EligeHoy
        Console.WriteLine("\n¿Que desea hacer el dia de hoy?\n");
        Console.WriteLine("1. Reabastecimiento de gasolina a depósitos. ");
        Console.WriteLine("2. Definir precio por galón de cada tipo de combustible. ");
        Console.WriteLine("3. Venta de gasolina a cliente final. ");
        Console.WriteLine("4. Información de ventas. ");
        Console.WriteLine("5. (BETA) Carga de ventas manuales por medio de un archivo. ");
        Console.WriteLine("6. Cerrar el programa. ");

        Console.WriteLine("\nElija el numero de lo que desea hacer: ");
        int Ops = int.Parse(Console.ReadLine());

        switch (Ops)
        {

            case 1: // Reabastecimiento de gasolina a depósitos
                {

                    // Elejiste ...
                    Reiniciar = false;
                    Console.WriteLine("\nEligiste: Reabastecimiento de gasolina a depósitos.\n");
                    //Objetos oObjetos = new Objetos();

                    // Usuario y contraseña  
                    oObjetos.Ingreso();

                    // Mostrar contenido y precio del combustible
                    oObjetos.GalonesDisponibles();

                    // Reabastecer combustible en los depocitos y/n
                    Console.WriteLine("\n¿Desea reabastecer combustible a los depósitos? y/n ");
                    oObjetos.SINO();

                    // Accion completada
                    Console.WriteLine("\n - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n");
                    Console.WriteLine("Has completado esta accion ahora porfavor elige...");
                    Reiniciar = true;

                }
                break;



            case 2: // Definir precio por galón de cada tipo de combustible
                {

                    // Elejiste ...
                    Reiniciar = false;
                    Console.WriteLine("\nElegiste: Definir precio por galón de cada tipo de combustible.\n");
                    

                    // Usuario y contraseña
                    oObjetos.Ingreso2();

                    // Mostrar datos
                    oObjetos.CostosDeGasolina();

                    // ¿Desea realizar el cambio del precio por galón de los combustibles?
                    Console.WriteLine("\n¿Desea realizar el cambio del precio por galón de los combustibles? y/n ");
                    oObjetos.SINO2();

                    // Accion completada
                    Console.WriteLine("\n - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n");
                    Console.WriteLine("Has completado esta accion ahora porfavor elige...");
                    Reiniciar = true;

                }
                break;



            case 3: // Venta de gasolina a cliente final
                {

                    // Elejiste ...
                    Reiniciar = false;
                    Console.WriteLine("\nElegiste: Venta de gasolina a cliente final.\n");
                    //Objetos oObjetos = new Objetos();

                    // Mostrar datos
                    oObjetos.PreciosActuales();

                    // Elige la bomba
                    oObjetos.EligBom();

                    // Accion completada
                    Console.WriteLine("\n - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n");
                    Console.WriteLine("Has completado esta accion ahora porfavor elige...");
                    Reiniciar = true;

                }
                break;



            case 4: // Venta de Información de ventas
                {

                    // Elejiste ...
                    Reiniciar = false;
                    Console.WriteLine("\nElegiste: Información_de_ventas.\n");
                    //Objetos oObjetos = new Objetos();

                    // Datos generales
                    oObjetos.DatosGenerales();

                    // Accion completada
                    Console.WriteLine("\n - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n");
                    Console.WriteLine("Has completado esta accion ahora porfavor elige...");
                    Reiniciar = true;

                }
                break;



            case 5: // Carga de ventas manuales por medio de un archivo
                {

                    // Elejiste ...
                    Reiniciar = false;
                    Console.WriteLine("\nElegiste: Carga de ventas manuales por medio de un archivo.\n");
                    //Objetos oObjetos = new Objetos();

                    Console.WriteLine("*** Esta opcion aun esta en desarrollo y no esta disponible actualmente. ***"); Reiniciar = true;

                    // Accion completada
                    Console.WriteLine("\n - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n");
                    Console.WriteLine("Has completado esta accion ahora porfavor elige...");
                    Reiniciar = true;

                }
                break;

            case 6: //Cerrar el programa
                {

                    Reiniciar = false;
                    Console.WriteLine("\nGracias por utilizar * Gasolineras el Fernando *, vuelva pronto");
                    Console.ReadKey();

                }
                break;

            default:
                {

                    // Elejiste ...
                    Reiniciar = true;
                    Console.WriteLine("\n*** Porfavor eliga una de las opciones dadas. ***");

                }
                break;

        }

    }
    while (Reiniciar == true);

}
catch
{

    Console.WriteLine("*** Se a producido un error en el programa, porfavor reinicie. ***");

}
