﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* **************************************************************************************************************************************************************
 
INDICE RAPIDO 

Objetos 1 = linea 86
 
Objetos 2 = linea 500

Objetos 3 = linea 678

Objetos 4 = linea 2034

Objetos 5 = linea 2107

************************************************************************************************************************************************************** */


namespace Class1_Reabastecimiento_de_gasolina_a_depósitos
{

    public class Objetos
    {

        // Bariables importantes 

        public double
        _Bomba1 = 0,
        _Bomba2 = 0,
        _Bomba3 = 0,
        _Bomba4 = 0,
        _Bomba5 = 0;

        public double
        _DepoDiesel = 500,
        _DepoRegular = 500,
        _DepoSuper = 500,
        _DepoPremium = 500;


        public double
        _PrecioDiesel = 15,
        _PrecioRegular = 15,
        _PrecioSuper = 18,
        _PrecioPremium = 20;


        public double
        _DiecelQ,
        _RegularQ,
        _SuperQ,
        _PremiumQ;

        public double
        DeudaDeGasolinera,
        GananciasGaso;




















        //--------------------------------------------------------------------------------------------------------------------------------------------------------------
        //--------------------------------------------------------------------------------------------------------------------------------------------------------------
        //--------------------------------------------------------------------------------------------------------------------------------------------------------------

        // ((((((((((((((( OBJETOS 1 )))))))))))))))

        // Usuario y contraseña

        public void Ingreso()
        {

            string 
            _Usuario,
            _Contraseña;

            bool _Continuar = false;

            try
            {
                do
                {
                    
                    Console.WriteLine("Porfavor ingrese su usuario y contraseña. ");
                    _Usuario = Console.ReadLine();
                    _Contraseña = Console.ReadLine();

                    if (_Usuario == "Bodoke" && _Contraseña == "Bodoke123")
                    {

                        _Continuar = true;
                        Console.WriteLine("Bienvenido devuelta " + _Usuario);


                    }

                    else
                    {

                        _Continuar = false;
                        Console.WriteLine("Usuario y/o contraseña incorrecta \n");

                    }

                }

                while(_Continuar == false);

            }

            catch
            {

                Console.WriteLine("Ha existido un error. Vuelva a ejecutar el programa");

            }

            
        }

    


        // ( Mostrar al operador la cantidad de combustible que poseen los cuatro depósitos de combustible. )





        public void GalonesDisponibles()
        {
            if (_DiecelQ < 1)
            {
                Console.WriteLine("\nGalones disponibles actuales:");
                Console.WriteLine("* Diesel = " + (_DepoDiesel) + "/2500 galones");
                Console.WriteLine("* Regular = " + (_DepoRegular) + "/2500 galones");
                Console.WriteLine("* Super = " + (_DepoSuper) + "/2500 galones");
                Console.WriteLine("* Premium = " + (_DepoPremium) + "/2500 galones");

            }
            else
            {

                Console.WriteLine("\nGalones disponibles actuales:");
                Console.WriteLine("* Diesel = " + (_DepoDiesel + _DiecelQ) + "/2500 galones");
                Console.WriteLine("* Regular = " + (_DepoRegular + _RegularQ) + "/2500 galones");
                Console.WriteLine("* Super = " + (_DepoSuper + _SuperQ) + "/2500 galones");
                Console.WriteLine("* Premium = " + (_DepoPremium + _PremiumQ) + "/2500 galones");

            }
        }



        // ( Reabastecer combustible en los depocitos y/n ) 



        public double 
        _RespuestaG1,
        _RespuestaG2,
        _RespuestaG3,
        _RespuestaG4;

        public double
        _PagoDiecel,
        _PagoRegular,
        _PagoSuper,
        _PagoPremium;



        public void SINO()
        {
            string _Continuar = Console.ReadLine();
            if (_Continuar == "Y".ToLower())
            {

                // Galones disponibles
                
                // Precio por galon

                
                Console.WriteLine("\nPrecio por galon:");
                Console.WriteLine("* Diesel = " + "Q. " + _PrecioDiesel);
                Console.WriteLine("* Regular = " + "Q. " + _PrecioRegular);
                Console.WriteLine("* Super = " + "Q. " + _PrecioSuper);
                Console.WriteLine("* Premium = " + "Q. " + _PrecioPremium);

                bool _ContinuarPago1 = true;
                bool _ContinuarPago2 = true;
                bool _ContinuarPago3 = true;
                bool _ContinuarPago4 = true;


                do
                {

                    Console.WriteLine("\nIndique la cantidad que galones que desea: ");
                    Console.WriteLine("Aviso: Si ocurre algun error en su compra se le notificara su error y devera recolocar los datos.\n");
                    Console.WriteLine("* Diesel: "); _DiecelQ = double.Parse(Console.ReadLine());
                    Console.WriteLine("* Regular: "); _RegularQ = double.Parse(Console.ReadLine());
                    Console.WriteLine("* Super: "); _SuperQ = double.Parse(Console.ReadLine());
                    Console.WriteLine("* Premium: "); _PremiumQ = double.Parse(Console.ReadLine());

                    // Comprobar resultados
                    //-------------------------------------------------- (Diesel)
                    
                    if (_DiecelQ == _DepoDiesel)
                    {

                        _ContinuarPago1 = false;
                        Console.WriteLine("(Diesel) Error de compra 1: *La cantidad de galones pedida es la misma que la cantidad maxima.*");

                        if (_DiecelQ > _DepoDiesel)
                        {

                            _ContinuarPago1 = false;
                            Console.WriteLine("(Diesel) Error de compra 2: *La cantidad de galones pedida sobrepasa la cantidad maxima.*");

                            //-------------------------------------------------- (Regular)

                            if (_RegularQ == _DepoRegular)
                            {

                                _ContinuarPago2 = false;
                                Console.WriteLine("(Regular) Error de compra 1: *La cantidad de galones pedida es la misma que la cantidad maxima.*");

                                if (_RegularQ > _DepoRegular)
                                {

                                    //-------------------------------------------------- (Super)

                                    _ContinuarPago2 = false;
                                    Console.WriteLine("(Regular) Error de compra 2: *La cantidad de galones pedida sobrepasa la cantidad maxima.*");

                                    if (_SuperQ == _DepoSuper)
                                    {

                                        _ContinuarPago3 = false;
                                        Console.WriteLine("(Super) Error de compra 1: *La cantidad de galones pedida es la misma que la cantidad maxima.*");

                                        if (_SuperQ > _DepoSuper)
                                        {

                                            //-------------------------------------------------- (Premium)

                                            _ContinuarPago3 = false;
                                            Console.WriteLine("(Super) Error de compra 2: *La cantidad de galones pedida sobrepasa la cantidad maxima.*");

                                            if (_PremiumQ == _DepoPremium)
                                            {

                                                _ContinuarPago4 = false;
                                                Console.WriteLine("(Premium) Error de compra 1: *La cantidad de galones pedida es la misma que la cantidad maxima.*");

                                                if (_PremiumQ > _DepoPremium)
                                                {

                                                    _ContinuarPago4 = false;
                                                    Console.WriteLine("(Premium) Error de compra 2: *La cantidad de galones pedida sobrepasa la cantidad maxima.*");

                                                }

                                            }

                                        }

                                    }

                                }

                            }

                        }

                    }

                    else
                    {

                        _ContinuarPago1 = true;
                        _ContinuarPago2 = true;
                        _ContinuarPago3 = true;
                        _ContinuarPago4 = true;

                        _RespuestaG1 = _DepoDiesel + _DiecelQ;
                        _RespuestaG2 = _DepoRegular + _RegularQ;
                        _RespuestaG3 = _DepoSuper + _SuperQ;
                        _RespuestaG4 = _DepoPremium + _PremiumQ;

                        //  Nuevos galones

                        _DepoDiesel = _RespuestaG1;
                        _DepoRegular = _RespuestaG2;
                        _DepoSuper = _RespuestaG3;
                        _DepoPremium = _RespuestaG4;

                        Console.WriteLine("\n*** COMPRA EXITOSA ***");

                        Console.WriteLine("\nGalones disponibles actuales:");
                        Console.WriteLine("* Diesel = " + (_DepoDiesel) + "/2500 galones");
                        Console.WriteLine("* Regular = " + (_DepoRegular) + "/2500 galones");
                        Console.WriteLine("* Super = " + (_DepoSuper) + "/2500 galones");
                        Console.WriteLine("* Premium = " + (_DepoPremium) + "/2500 galones");




                    }

                }
                
                while (_ContinuarPago1 == false); while (_ContinuarPago2 == false); while (_ContinuarPago3 == false); while (_ContinuarPago4 == false);


                double _Total = _PrecioDiesel + _PrecioRegular + _PrecioSuper + _PrecioPremium;

                double
                _IVADiesel = _PrecioDiesel * 0.12,
                _IVARegular = _PrecioRegular * 0.12,
                _IVASuper = _PrecioSuper * 0.12,
                _IVAPremium = _PrecioPremium * 0.12;

                double _TotalIVA = _IVADiesel + _IVARegular + _IVASuper + _IVAPremium;

                double
                _TODiesel = _PrecioDiesel + _IVADiesel,
                _TORegular = _PrecioRegular + _IVARegular,
                _TOSuper = _PrecioSuper + _IVASuper,
                _TOPremium = _PrecioPremium + _IVAPremium;

                double _TOTotal = _TODiesel + _TORegular + _TOSuper + _TOPremium;

                double
                _TOTALDiesel = _TODiesel * 1.11,
                _TOTALRegular = _TORegular * 1.11,
                _TOTALSuper = _TOSuper * 1.11,
                _TOTALPremium = _TOPremium * 1.11;

                double _TOTALTotal = _TOTALDiesel + _TOTALRegular + _TOTALSuper + _TOTALPremium;

                // Factura

                Console.WriteLine("\nFACTURA: ");


                Console.WriteLine("\nCosto por galones: ");
                Console.WriteLine("* Diesel = Q. " + _PrecioDiesel);
                Console.WriteLine("* Regular = Q. "+ _PrecioRegular);
                Console.WriteLine("* Super = Q. "+ _PrecioSuper);
                Console.WriteLine("* Premium = Q. "+ _PrecioPremium);
                Console.WriteLine("* Total: *** Q. " + _Total + " ***");

                Console.WriteLine("\nCosto de galones con IVA: ");
                Console.WriteLine("* Diesel = Q. " + _IVADiesel);
                Console.WriteLine("* Regular = Q. "+ _IVARegular);
                Console.WriteLine("* Super = Q. "+ _IVASuper);
                Console.WriteLine("* Premium = Q. "+ _IVAPremium);
                Console.WriteLine("* Total: *** Q. " + _TotalIVA + " ***");

                Console.WriteLine("\nCosto Sin: ");
                Console.WriteLine("* Diesel = Q. " + _TODiesel);
                Console.WriteLine("* Regular = Q. "+ _TORegular);
                Console.WriteLine("* Super = Q. "+ _TOSuper);
                Console.WriteLine("* Premium = Q. "+ _TOPremium);
                Console.WriteLine("* Total: *** Q. " + _TOTotal + " ***");

                Console.WriteLine("\nCosto TOTAL / Final: ");
                Console.WriteLine("* Diesel = Q. " + _TOTALDiesel);
                Console.WriteLine("* Regular = Q. "+ _TOTALRegular);
                Console.WriteLine("* Super = Q. "+ _TOTALSuper);
                Console.WriteLine("* Premium = Q. "+ _TOTALPremium);
                Console.WriteLine("* Total: *** Q. " + _TOTALTotal + " ***");

                try
                {

                    // Metodo de pago

                    Console.WriteLine("\n¿Metodo de pago?");

                    Console.WriteLine("1. Al Credito ");
                    Console.WriteLine("2. Al Contado ");
                    bool Pago = true;

                    do
                    {

                        Console.WriteLine("\nElija el numero de lo que desea hacer: ");
                        int Ops = int.Parse(Console.ReadLine());
                        
                        switch (Ops)
                        {

                            case 1:
                            {

                                Pago = true;
                                Console.WriteLine("\nEligiste pagar: Al Credito.\n");
                                DeudaDeGasolinera =+ _TOTALTotal;
                                Console.WriteLine("Deuda actual: " + DeudaDeGasolinera);

                            }
                            break;

                            case 2:
                            {

                                Pago = true;
                                Console.WriteLine("\nEligiste pagar: Al Contador.\n");
                                GananciasGaso =- _TOTALTotal;
                                Console.WriteLine("Ganancias actuales: " + GananciasGaso);

                            }
                            break;

                            default:
                            {

                                Pago = false;
                                Console.WriteLine("\n*** Porfavor eliga una de las opciones dadas. ***");

                            }
                            break;


                        }
                        

                    }
                    while (Pago == false);

                }
                catch
                {

                    Console.WriteLine("*** Se a producido un error en el programa, porfavor reinicie. ***");

                }

            }

            else
            {

                // Cierra la clase
                Console.WriteLine("\nENTENDIDO");

            }

        }























        //--------------------------------------------------------------------------------------------------------------------------------------------------------------
        //--------------------------------------------------------------------------------------------------------------------------------------------------------------
        //--------------------------------------------------------------------------------------------------------------------------------------------------------------

        // ((((((((((((((( OBJETOS 2 )))))))))))))))

        public double
        _PrecioDieselC = 31.11,
        _PrecioRegularC = 31.84,
        _PrecioSuperC = 33.33,
        _PrecioPremiumC = 34.10;

        // Usuario y contraseña
        public void Ingreso2()
        {

                string
                _Usuario,
                _Contraseña;

                bool _Continuar = false;

            try
            {
                do
                {

                    Console.WriteLine("Porfavor ingrese su usuario y contraseña. ");
                    _Usuario = Console.ReadLine();
                    _Contraseña = Console.ReadLine();

                    if (_Usuario == "Bodoke" && _Contraseña == "Bodoke123")
                    {

                        _Continuar = true;
                        Console.WriteLine("Bienvenido devuelta " + _Usuario);

                    }

                    else
                    {

                        _Continuar = false;
                        Console.WriteLine("Usuario y/o contraseña incorrecta \n");
    
                    }

                }

                while (_Continuar == false);

            }

            catch
            {

               Console.WriteLine("Ha existido un error. Vuelva a ejecutar el programa");

            }

        }


        public void CostosDeGasolina()
        {
            
            //Mostrar precios

            Console.WriteLine("\nPrecio por galon:");
            Console.WriteLine("* Diesel = " + "Q. " + _PrecioDieselC);
            Console.WriteLine("* Regular = " + "Q. " + _PrecioRegularC);
            Console.WriteLine("* Super = " + "Q. " + _PrecioSuperC);
            Console.WriteLine("* Premium = " + "Q. " + _PrecioPremiumC);

        }

        public void SINO2()
        {

            string _Continuar = Console.ReadLine();
            bool _Reiniciar = false;

            if (_Continuar == "Y".ToLower())
            {
                do
                {
                    // Nuevos valores para combustible

                    Console.WriteLine("\nDetermina los nuevos valores de cada combustible:");
                    Console.WriteLine("* Diesel: "); double _PrecioDiesel2 = double.Parse(Console.ReadLine());
                    Console.WriteLine("* Regular: "); double _PrecioRegular2 = double.Parse(Console.ReadLine());
                    Console.WriteLine("* Super: "); double _PrecioSuper2 = double.Parse(Console.ReadLine());
                    Console.WriteLine("* Premium: "); double _PrecioPremium2 = double.Parse(Console.ReadLine());

                    if (_PrecioDiesel2 < _PrecioDieselC)
                    {

                        _Reiniciar = true;
                        Console.WriteLine("Este precio generará pérdidas a la gasolinera.");
                        Console.WriteLine("Porfavor reingrese los datos.");

                    }
                    else if (_PrecioRegular2 < _PrecioRegularC)
                    {

                        _Reiniciar = true;
                        Console.WriteLine("Este precio generará pérdidas a la gasolinera.");
                        Console.WriteLine("Porfavor reingrese los datos.");

                    }
                    else if (_PrecioSuper2 < _PrecioSuperC)
                    {

                        _Reiniciar = true;
                        Console.WriteLine("Este precio generará pérdidas a la gasolinera.");
                        Console.WriteLine("Porfavor reingrese los datos.");

                    }
                    else if (_PrecioPremium2 < _PrecioPremiumC)
                    {

                        _Reiniciar = true;
                        Console.WriteLine("Este precio generará pérdidas a la gasolinera.");
                        Console.WriteLine("Porfavor reingrese los datos.");

                    }
                    else
                    {

                        _PrecioDieselC = _PrecioDiesel2;
                        _PrecioRegularC = _PrecioRegular2;
                        _PrecioSuperC = _PrecioSuper2;
                        _PrecioPremiumC = _PrecioPremium2;

                        _Reiniciar = false;

                        // Costos Actuales

                        Console.WriteLine("\nCostos actuales:");
                        Console.WriteLine("* Diesel = " + "Q. " + _PrecioDieselC);
                        Console.WriteLine("* Regular = " + "Q. " + _PrecioRegularC);
                        Console.WriteLine("* Super = " + "Q. " + _PrecioSuperC);
                        Console.WriteLine("* Premium = " + "Q. " + _PrecioPremiumC);

                    }

                } while (_Reiniciar == true);

            }
            else
            {

                // Cierra la clase
                Console.WriteLine("ENTENDIDO");

            }

        }




















        //--------------------------------------------------------------------------------------------------------------------------------------------------------------
        //--------------------------------------------------------------------------------------------------------------------------------------------------------------
        //--------------------------------------------------------------------------------------------------------------------------------------------------------------

        // ((((((((((((((( OBJETOS 3 )))))))))))))))


        // Total de galones y quetzales vendidos por cada bomba. 

        public double
            Bomba1G, Bomba2G, Bomba3G, Bomba4G, Bomba5G,
            Bomba1Q, Bomba2Q, Bomba3Q, Bomba4Q, Bomba5Q;

        // Total de galones y quetzales vendidos para cada tipo de combustible.

        public double
            DieselGven, RegularGven, SuperGven, PremiumGven,
            DieselQven, RegularQven, SuperQven, PremiumQven;

        //Datos de precios
        public void PreciosActuales()
        {

            Console.WriteLine("\nCostos actuales:");
            Console.WriteLine("* Diesel = " + "Q. " + _PrecioDieselC);
            Console.WriteLine("* Regular = " + "Q. " + _PrecioRegularC);
            Console.WriteLine("* Super = " + "Q. " + _PrecioSuperC);
            Console.WriteLine("* Premium = " + "Q. " + _PrecioPremiumC);


        }

        // Seleccionar la bomba que quiere utilizar

        public void EligBom()
        {



            Console.WriteLine("\nElige la bomba a utilizar: ");
            Console.WriteLine("* Bomba 1");
            Console.WriteLine("* Bomba 2");
            Console.WriteLine("* Bomba 3");
            Console.WriteLine("* Bomba 4");
            Console.WriteLine("* Bomba 5");

            bool Continuar = true;

            do 
            {
            
                Console.WriteLine("\nElige el numero de la bomba que desea utilizar");
                double Elig = double.Parse(Console.ReadLine());
            

                if (Elig > 0 && Elig < 6)
                {
                    
                            Continuar = true;
                            Console.WriteLine("\nA elegido la Bomba" + Elig);

                            Console.WriteLine("\nGalones disponibles por combustible:");
                            Console.WriteLine("* Diesel = " + _DepoDiesel);
                            Console.WriteLine("* Regular = " + _DepoRegular);
                            Console.WriteLine("* Super = " + _DepoSuper);
                            Console.WriteLine("* Premium = " + _DepoPremium);

                    // Error de venta

                    if (_DepoDiesel == 0)
                    {

                        Console.WriteLine("\n* Lo sentimos, pero no tenemos combustible disponible, vuelva intentrlo mas tarde. *");

                        if (_DepoRegular == 0)
                        {

                            Console.WriteLine("\n* Lo sentimos, pero no tenemos combustible disponible, vuelva intentrlo mas tarde. *");

                            if (_DepoSuper == 0)
                            {

                                Console.WriteLine("\n* Lo sentimos, pero no tenemos combustible disponible, vuelva intentrlo mas tarde. *");

                                if (_DepoPremium == 0)
                                {

                                    Console.WriteLine("\n* Lo sentimos, pero no tenemos combustible disponible, vuelva intentrlo mas tarde. *");

                                }

                            }

                        }

                    }

                    // Venta diponible

                    else
                    {

                        Console.WriteLine("\n¿Que tipo de venta prefieres?");
                        Console.WriteLine("1. Venta y despacho manual al cliente");
                        Console.WriteLine("2. Venta y despacho automático al cliente");

                        bool _Continuar = true;
                        bool Continuar2 = true;

                        do
                        {

                            Console.WriteLine("\nElige el numero de la venta que deseas.");
                            double Res = double.Parse(Console.ReadLine());


                            // ---------------------------------------------------------- ( Opcion 1 )

                            if (Res == 1)
                            {

                                _Continuar = true;

                                Console.WriteLine("\nElegiste: Venta y despacho manual al cliente.");

                                do
                                {

                                    Console.WriteLine("\nTipos de combustible: ");
                                    Console.WriteLine("1. Diesel");
                                    Console.WriteLine("2. Regular");
                                    Console.WriteLine("3. Super");
                                    Console.WriteLine("4. Premium");

                                    Console.WriteLine("\nElige el numero del combustible deseas");
                                    double TDC = double.Parse(Console.ReadLine());

                                    switch (TDC)
                                    {

                                        case 1:
                                            {

                                                Continuar2 = true;
                                                Console.WriteLine("\nElegiste combustible: Diesel");
                                                Console.WriteLine("Ingrese la cantidad de combustible deseada en quetzales.");
                                                double Quiero = double.Parse(Console.ReadLine());

                                                if (Quiero > (_PrecioDieselC * _DepoDiesel))
                                                {

                                                    Console.WriteLine("\nEl valor soliciado es mayor al limite de existentes actualmente.");
                                                    Console.WriteLine("Pero ofresemos un pago completo del combustible actual");
                                                    Console.WriteLine("Con un total de: Q. " + _PrecioDieselC * _DepoDiesel);

                                                    Console.WriteLine("\n¿Desea ejecutar esta acción? y/n");
                                                    string Res1 = Console.ReadLine().ToLower();

                                                    if (Res1 == "Y".ToLower())
                                                    {

                                                        Console.WriteLine("\n*** Compra Exitosa ***");
                                                        Console.WriteLine("* Su total a pagar es: Q. " + (_PrecioDieselC * _DepoDiesel));
                                                        Console.WriteLine("* Su cambio es de: Q. " + (Quiero - (_PrecioDieselC * _DepoDiesel)));

                                                        DeudaDeGasolinera = DeudaDeGasolinera - (_PrecioDieselC * _DepoDiesel);
                                                        GananciasGaso = GananciasGaso + (_PrecioDieselC * _DepoDiesel);

                                                        // Datasos

                                                        if (Elig == 1) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 1 )
                                                        {

                                                            Bomba1G = Bomba1G + _DepoDiesel;
                                                            Bomba1Q = Bomba1Q + (_PrecioDieselC * _DepoDiesel);

                                                            DieselGven = DieselGven + _DepoDiesel;
                                                            DieselQven = DieselQven + (_PrecioDieselC * _DepoDiesel);

                                                        }
                                                        if (Elig == 2) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 2 )
                                                        {

                                                            Bomba2G = Bomba2G + _DepoDiesel;
                                                            Bomba2Q = Bomba2Q + (_PrecioDieselC * _DepoDiesel);

                                                            DieselGven = DieselGven + _DepoDiesel;
                                                            DieselQven = DieselQven + (_PrecioDieselC * _DepoDiesel);

                                                        }
                                                        if (Elig == 3) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 3 )
                                                        {

                                                            Bomba3G = Bomba3G + _DepoDiesel;
                                                            Bomba3Q = Bomba3Q + (_PrecioDieselC * _DepoDiesel);

                                                            DieselGven = DieselGven + _DepoDiesel;
                                                            DieselQven = DieselQven + (_PrecioDieselC * _DepoDiesel);

                                                        }
                                                        if (Elig == 4) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 4 )
                                                        {

                                                            Bomba4G = Bomba4G + _DepoDiesel;
                                                            Bomba4Q = Bomba4Q + (_PrecioDieselC * _DepoDiesel);

                                                            DieselGven = DieselGven + _DepoDiesel;
                                                            DieselQven = DieselQven + (_PrecioDieselC * _DepoDiesel);

                                                        }
                                                        if (Elig == 5) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 5 )
                                                        {

                                                            Bomba5G = Bomba5G + _DepoDiesel;
                                                            Bomba5Q = Bomba5Q + (_PrecioDieselC * _DepoDiesel);

                                                            DieselGven = DieselGven + _DepoDiesel;
                                                            DieselQven = DieselQven + (_PrecioDieselC * _DepoDiesel);

                                                        }

                                                        _DepoDiesel = 0;

                                                        Console.WriteLine("\n¿Desea seguir comprando combustible? y/n");
                                                        string Res2 = Console.ReadLine().ToLower();

                                                        if (Res2 == "Y".ToLower())
                                                        {

                                                            Continuar2 = false;

                                                        }
                                                        else
                                                        {

                                                            Continuar2 = true;

                                                        }

                                                    }
                                                    else
                                                    {

                                                        Console.WriteLine("\nEntendido, porofavor reingrese una nueva cantidad.");
                                                        Continuar2 = false;

                                                    }

                                                }
                                                else
                                                {

                                                    Console.WriteLine("\n*** Compra Exitosa ***");
                                                    Console.WriteLine("* Su total es de galones es de: " + ((_PrecioDieselC / _DepoDiesel) / (Quiero * _DepoDiesel)));

                                                    _DepoDiesel = _DepoDiesel - ((_PrecioDieselC / _DepoDiesel) / (Quiero * _DepoDiesel));
                                                    DeudaDeGasolinera = DeudaDeGasolinera - Quiero;
                                                    GananciasGaso = GananciasGaso + Quiero;

                                                    // Datasos

                                                    if (Elig == 1) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 1 )
                                                    {

                                                        Bomba1G = Bomba1G + ((_PrecioDieselC / _DepoDiesel) / (Quiero * _DepoDiesel));
                                                        Bomba1Q = Bomba1Q + Quiero;

                                                        DieselGven = DieselGven + ((_PrecioDieselC / _DepoDiesel) / (Quiero * _DepoDiesel));
                                                        DieselQven = DieselQven + Quiero;

                                                    }
                                                    if (Elig == 2) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 2 )
                                                    {

                                                        Bomba2G = Bomba2G + ((_PrecioDieselC / _DepoDiesel) / (Quiero * _DepoDiesel));
                                                        Bomba2Q = Bomba2Q + Quiero;

                                                        DieselGven = DieselGven + ((_PrecioDieselC / _DepoDiesel) / (Quiero * _DepoDiesel));
                                                        DieselQven = DieselQven + Quiero;

                                                    }
                                                    if (Elig == 3) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 3 )
                                                    {

                                                        Bomba3G = Bomba3G + ((_PrecioDieselC / _DepoDiesel) / (Quiero * _DepoDiesel));
                                                        Bomba3Q = Bomba3Q + Quiero;

                                                        DieselGven = DieselGven + ((_PrecioDieselC / _DepoDiesel) / (Quiero * _DepoDiesel));
                                                        DieselQven = DieselQven + Quiero;

                                                    }
                                                    if (Elig == 4) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 4 )
                                                    {

                                                        Bomba4G = Bomba4G + ((_PrecioDieselC / _DepoDiesel) / (Quiero * _DepoDiesel));
                                                        Bomba4Q = Bomba4Q + Quiero;

                                                        DieselGven = DieselGven + ((_PrecioDieselC / _DepoDiesel) / (Quiero * _DepoDiesel));
                                                        DieselQven = DieselQven + Quiero;

                                                    }
                                                    if (Elig == 5) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 5 )
                                                    {

                                                        Bomba5G = Bomba5G + ((_PrecioDieselC / _DepoDiesel) / (Quiero * _DepoDiesel));
                                                        Bomba5Q = Bomba5Q + Quiero;

                                                        DieselGven = DieselGven + ((_PrecioDieselC / _DepoDiesel) / (Quiero * _DepoDiesel));
                                                        DieselQven = DieselQven + Quiero;

                                                    }

                                                    Console.WriteLine("\n¿Desea seguir comprando combustible? y/n");
                                                    string Res2 = Console.ReadLine().ToLower();

                                                    if (Res2 == "Y".ToLower())
                                                    {

                                                        Continuar2 = false;

                                                    }
                                                    else
                                                    {

                                                        Continuar2 = true;

                                                    }

                                                }

                                            }
                                            break;

                                        case 2:
                                            {

                                                Continuar2 = true;
                                                Console.WriteLine("\nElegiste combustible: Regular");
                                                Console.WriteLine("Ingrese la cantidad de combustible deseada en quetzales.");
                                                double Quiero = double.Parse(Console.ReadLine());

                                                if (Quiero > (_PrecioRegularC * _DepoRegular))
                                                {

                                                    Console.WriteLine("\nEl valor soliciado es mayor al limite de existentes actualmente.");
                                                    Console.WriteLine("Pero ofresemos un pago completo del combustible actual");
                                                    Console.WriteLine("Con un total de: Q. " + _PrecioRegularC * _DepoRegular);

                                                    Console.WriteLine("\n¿Desea ejecutar esta acción? y/n");
                                                    string Res2 = Console.ReadLine().ToLower();

                                                    if (Res2 == "Y".ToLower())
                                                    {

                                                        Console.WriteLine("\n*** Compra Exitosa ***");
                                                        Console.WriteLine("* Su total a pagar es: Q. " + (_PrecioRegularC * _DepoRegular));
                                                        Console.WriteLine("* Su cambio es de: Q. " + (Quiero - (_PrecioRegularC * _DepoRegular)));

                                                        DeudaDeGasolinera = DeudaDeGasolinera - (_PrecioRegularC * _DepoRegular);
                                                        GananciasGaso = GananciasGaso + (_PrecioRegularC * _DepoRegular);

                                                        // Datasos

                                                        if (Elig == 1) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 1 )
                                                        {

                                                            Bomba1G = Bomba1G + _DepoRegular;
                                                            Bomba1Q = Bomba1Q + (_PrecioRegularC * _DepoRegular);

                                                            RegularGven = RegularGven + _DepoRegular;
                                                            RegularQven = RegularQven + (_PrecioRegularC * _DepoRegular);

                                                        }
                                                        if (Elig == 2) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 2 )
                                                        {

                                                            Bomba2G = Bomba2G + _DepoRegular;
                                                            Bomba2Q = Bomba2Q + (_PrecioRegularC * _DepoRegular);

                                                            RegularGven = RegularGven + _DepoRegular;
                                                            RegularQven = RegularQven + (_PrecioRegularC * _DepoRegular);

                                                        }
                                                        if (Elig == 3) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 3 )
                                                        {

                                                            Bomba3G = Bomba3G + _DepoRegular;
                                                            Bomba3Q = Bomba3Q + (_PrecioRegularC * _DepoRegular);

                                                            RegularGven = RegularGven + _DepoRegular;
                                                            RegularQven = RegularQven + (_PrecioRegularC * _DepoRegular);

                                                        }
                                                        if (Elig == 4) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 4 )
                                                        {

                                                            Bomba4G = Bomba4G + _DepoRegular;
                                                            Bomba4Q = Bomba4Q + (_PrecioRegularC * _DepoRegular);

                                                            RegularGven = RegularGven + _DepoRegular;
                                                            RegularQven = RegularQven + (_PrecioRegularC * _DepoRegular);

                                                        }
                                                        if (Elig == 5) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 5 )
                                                        {

                                                            Bomba5G = Bomba5G + _DepoRegular;
                                                            Bomba5Q = Bomba5Q + (_PrecioRegularC * _DepoRegular);

                                                            RegularGven = RegularGven + _DepoRegular;
                                                            RegularQven = RegularQven + (_PrecioRegularC * _DepoRegular);

                                                        }

                                                        _DepoRegular = 0;

                                                        Console.WriteLine("\n¿Desea seguir comprando combustible? y/n");
                                                        string Res3 = Console.ReadLine().ToLower();

                                                        if (Res3 == "Y".ToLower())
                                                        {

                                                            Continuar2 = false;

                                                        }
                                                        else
                                                        {

                                                            Continuar2 = true;

                                                        }

                                                    }
                                                    else
                                                    {

                                                        Console.WriteLine("\nEntendido, porofavor reingrese una nueva cantidad.");
                                                        Continuar2 = false;

                                                    }

                                                }
                                                else
                                                {

                                                    Console.WriteLine("\n*** Compra Exitosa ***");
                                                    Console.WriteLine("* Su total es de galones es de: " + ((_PrecioRegularC / _DepoRegular) / (Quiero * _DepoRegular)));

                                                    _DepoRegular = _DepoRegular - ((_PrecioRegularC / _DepoRegular) / (Quiero * _DepoRegular));
                                                    DeudaDeGasolinera = DeudaDeGasolinera - Quiero;
                                                    GananciasGaso = GananciasGaso + Quiero;

                                                    // Datasos

                                                    if (Elig == 1) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 1 )
                                                    {

                                                        Bomba1G = Bomba1G + ((_PrecioRegularC / _DepoRegular) / (Quiero * _DepoRegular));
                                                        Bomba1Q = Bomba1Q + Quiero;

                                                        RegularGven = RegularGven + ((_PrecioRegularC / _DepoRegular) / (Quiero * _DepoRegular));
                                                        RegularQven = RegularQven + Quiero;

                                                    }
                                                    if (Elig == 2) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 2 )
                                                    {

                                                        Bomba2G = Bomba2G + ((_PrecioRegularC / _DepoRegular) / (Quiero * _DepoRegular));
                                                        Bomba2Q = Bomba2Q + Quiero;

                                                        RegularGven = RegularGven + ((_PrecioRegularC / _DepoRegular) / (Quiero * _DepoRegular));
                                                        RegularQven = RegularQven + Quiero;

                                                    }
                                                    if (Elig == 3) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 3 )
                                                    {

                                                        Bomba3G = Bomba3G + ((_PrecioRegularC / _DepoRegular) / (Quiero * _DepoRegular));
                                                        Bomba3Q = Bomba3Q + Quiero;

                                                        RegularGven = RegularGven + ((_PrecioRegularC / _DepoRegular) / (Quiero * _DepoRegular));
                                                        RegularQven = RegularQven + Quiero;

                                                    }
                                                    if (Elig == 4) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 4 )
                                                    {

                                                        Bomba4G = Bomba4G + ((_PrecioRegularC / _DepoRegular) / (Quiero * _DepoRegular));
                                                        Bomba4Q = Bomba4Q + Quiero;

                                                        RegularGven = RegularGven + ((_PrecioRegularC / _DepoRegular) / (Quiero * _DepoRegular));
                                                        RegularQven = RegularQven + Quiero;

                                                    }
                                                    if (Elig == 5) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 5 )
                                                    {

                                                        Bomba5G = Bomba5G + ((_PrecioRegularC / _DepoRegular) / (Quiero * _DepoRegular));
                                                        Bomba5Q = Bomba5Q + Quiero;

                                                        RegularGven = RegularGven + ((_PrecioRegularC / _DepoRegular) / (Quiero * _DepoRegular));
                                                        RegularQven = RegularQven + Quiero;

                                                    }

                                                    Console.WriteLine("\n¿Desea seguir comprando combustible? y/n");
                                                    string Res2 = Console.ReadLine().ToLower();

                                                    if (Res2 == "Y".ToLower())
                                                    {

                                                        Continuar2 = false;

                                                    }
                                                    else
                                                    {

                                                        Continuar2 = true;

                                                    }

                                                }

                                            }
                                            break;

                                        case 3:
                                            {

                                                Continuar2 = true;
                                                Console.WriteLine("\nElegiste combustible: Super");
                                                Console.WriteLine("Ingrese la cantidad de combustible deseada en quetzales.");
                                                double Quiero = double.Parse(Console.ReadLine());

                                                if (Quiero > (_PrecioSuperC * _DepoSuper))
                                                {

                                                    Console.WriteLine("\nEl valor soliciado es mayor al limite de existentes actualmente.");
                                                    Console.WriteLine("Pero ofresemos un pago completo del combustible actual");
                                                    Console.WriteLine("Con un total de: Q. " + _PrecioSuperC * _DepoSuper);

                                                    Console.WriteLine("\n¿Desea ejecutar esta acción? y/n");
                                                    string Res4 = Console.ReadLine().ToLower();

                                                    if (Res4 == "Y".ToLower())
                                                    {

                                                        Console.WriteLine("\n*** Compra Exitosa ***");
                                                        Console.WriteLine("* Su total a pagar es: Q. " + (_PrecioSuperC * _DepoSuper));
                                                        Console.WriteLine("* Su cambio es de: Q. " + (Quiero - (_PrecioSuperC * _DepoSuper)));

                                                        DeudaDeGasolinera = DeudaDeGasolinera - (_PrecioSuperC * _DepoSuper);
                                                        GananciasGaso = GananciasGaso + (_PrecioSuperC * _DepoSuper);

                                                        // Datasos

                                                        if (Elig == 1) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 1 )
                                                        {

                                                            Bomba1G = Bomba1G + _DepoSuper;
                                                            Bomba1Q = Bomba1Q + (_PrecioSuperC * _DepoSuper);

                                                            SuperGven = SuperGven + _DepoSuper;
                                                            SuperQven = SuperQven + (_PrecioSuperC * _DepoSuper);

                                                        }
                                                        if (Elig == 2) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 2 )
                                                        {

                                                            Bomba2G = Bomba2G + _DepoSuper;
                                                            Bomba2Q = Bomba2Q + (_PrecioSuperC * _DepoSuper);

                                                            SuperGven = SuperGven + _DepoSuper;
                                                            SuperQven = SuperQven + (_PrecioSuperC * _DepoSuper);

                                                        }
                                                        if (Elig == 3) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 3 )
                                                        {

                                                            Bomba3G = Bomba3G + _DepoSuper;
                                                            Bomba3Q = Bomba3Q + (_PrecioSuperC * _DepoSuper);

                                                            SuperGven = SuperGven + _DepoSuper;
                                                            SuperQven = SuperQven + (_PrecioSuperC * _DepoSuper);

                                                        }
                                                        if (Elig == 4) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 4 )
                                                        {

                                                            Bomba4G = Bomba4G + _DepoSuper;
                                                            Bomba4Q = Bomba4Q + (_PrecioSuperC * _DepoSuper);

                                                            SuperGven = SuperGven + _DepoSuper;
                                                            SuperQven = SuperQven + (_PrecioSuperC * _DepoSuper);

                                                        }
                                                        if (Elig == 5) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 5 )
                                                        {

                                                            Bomba5G = Bomba5G + _DepoSuper;
                                                            Bomba5Q = Bomba5Q + (_PrecioSuperC * _DepoSuper);

                                                            SuperGven = SuperGven + _DepoSuper;
                                                            SuperQven = SuperQven + (_PrecioSuperC * _DepoSuper);

                                                        }

                                                        _DepoSuper = 0;

                                                        Console.WriteLine("\n¿Desea seguir comprando combustible? y/n");
                                                        string Res2 = Console.ReadLine().ToLower();

                                                        if (Res2 == "Y".ToLower())
                                                        {

                                                            Continuar2 = false;

                                                        }
                                                        else
                                                        {

                                                            Continuar2 = true;

                                                        }

                                                    }
                                                    else
                                                    {

                                                        Console.WriteLine("\nEntendido, porofavor reingrese una nueva cantidad.");
                                                        Continuar2 = false;

                                                    }

                                                }
                                                else
                                                {

                                                    Console.WriteLine("\n*** Compra Exitosa ***");
                                                    Console.WriteLine("* Su total es de galones es de: " + ((_PrecioSuperC / _DepoSuper) / (Quiero * _DepoSuper)));

                                                    _DepoSuper = _DepoSuper - ((_PrecioSuperC / _DepoSuper) / (Quiero * _DepoSuper));
                                                    DeudaDeGasolinera = DeudaDeGasolinera - Quiero;
                                                    GananciasGaso = GananciasGaso + Quiero;

                                                    // Datasos

                                                    if (Elig == 1) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 1 )
                                                    {

                                                        Bomba1G = Bomba1G + ((_PrecioSuperC / _DepoSuper) / (Quiero * _DepoSuper));
                                                        Bomba1Q = Bomba1Q + Quiero;

                                                        SuperGven = SuperGven + ((_PrecioSuperC / _DepoSuper) / (Quiero * _DepoSuper));
                                                        SuperQven = SuperQven + Quiero;

                                                    }
                                                    if (Elig == 2) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 2 )
                                                    {

                                                        Bomba2G = Bomba2G + ((_PrecioSuperC / _DepoSuper) / (Quiero * _DepoSuper));
                                                        Bomba2Q = Bomba2Q + Quiero;

                                                        SuperGven = SuperGven + ((_PrecioSuperC / _DepoSuper) / (Quiero * _DepoSuper));
                                                        SuperQven = SuperQven + Quiero;

                                                    }
                                                    if (Elig == 3) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 3 )
                                                    {

                                                        Bomba3G = Bomba3G + ((_PrecioSuperC / _DepoSuper) / (Quiero * _DepoSuper));
                                                        Bomba3Q = Bomba3Q + Quiero;

                                                        SuperGven = SuperGven + ((_PrecioSuperC / _DepoSuper) / (Quiero * _DepoSuper));
                                                        SuperQven = SuperQven + Quiero;

                                                    }
                                                    if (Elig == 4) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 4 )
                                                    {

                                                        Bomba4G = Bomba4G + ((_PrecioSuperC / _DepoSuper) / (Quiero * _DepoSuper));
                                                        Bomba4Q = Bomba4Q + Quiero;

                                                        SuperGven = SuperGven + ((_PrecioSuperC / _DepoSuper) / (Quiero * _DepoSuper));
                                                        SuperQven = SuperQven + Quiero;

                                                    }
                                                    if (Elig == 5) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 5 )
                                                    {

                                                        Bomba5G = Bomba5G + ((_PrecioSuperC / _DepoSuper) / (Quiero * _DepoSuper));
                                                        Bomba5Q = Bomba5Q + Quiero;

                                                        SuperGven = SuperGven + ((_PrecioSuperC / _DepoSuper) / (Quiero * _DepoSuper));
                                                        SuperQven = SuperQven + Quiero;

                                                    }

                                                    Console.WriteLine("\n¿Desea seguir comprando combustible? y/n");
                                                    string Res2 = Console.ReadLine().ToLower();

                                                    if (Res2 == "Y".ToLower())
                                                    {

                                                        Continuar2 = false;

                                                    }
                                                    else
                                                    {

                                                        Continuar2 = true;

                                                    }

                                                }

                                            }
                                            break;

                                        case 4:
                                            {

                                                Continuar2 = true;
                                                Console.WriteLine("\nElegiste combustible: Premium");
                                                Console.WriteLine("Ingrese la cantidad de combustible deseada en quetzales.");
                                                double Quiero = double.Parse(Console.ReadLine());

                                                if (Quiero > (_PrecioPremiumC * _DepoPremium))
                                                {

                                                    Console.WriteLine("\nEl valor soliciado es mayor al limite de existentes actualmente.");
                                                    Console.WriteLine("Pero ofresemos un pago completo del combustible actual");
                                                    Console.WriteLine("Con un total de: Q. " + _PrecioPremiumC * _DepoPremium);

                                                    Console.WriteLine("\n¿Desea ejecutar esta acción? y/n");
                                                    string Res5 = Console.ReadLine().ToLower();

                                                    if (Res5 == "Y".ToLower())
                                                    {

                                                        Console.WriteLine("\n*** Compra Exitosa ***");
                                                        Console.WriteLine("* Su total a pagar es: Q. " + (_PrecioPremiumC * _DepoPremium));
                                                        Console.WriteLine("* Su cambio es de: Q. " + (Quiero - (_PrecioPremiumC * _DepoPremium)));

                                                        DeudaDeGasolinera = DeudaDeGasolinera - (_PrecioPremiumC * _DepoPremium);
                                                        GananciasGaso = GananciasGaso + (_PrecioPremiumC * _DepoPremium);

                                                        // Datasos

                                                        if (Elig == 1) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 1 )
                                                        {

                                                            Bomba1G = Bomba1G + _DepoPremium;
                                                            Bomba1Q = Bomba1Q + (_PrecioPremiumC * _DepoPremium);

                                                            PremiumGven = PremiumGven + _DepoPremium;
                                                            PremiumQven = PremiumQven + (_PrecioPremiumC * _DepoPremium);

                                                        }
                                                        if (Elig == 2) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 2 )
                                                        {

                                                            Bomba2G = Bomba2G + _DepoPremium;
                                                            Bomba2Q = Bomba2Q + (_PrecioPremiumC * _DepoPremium);

                                                            PremiumGven = PremiumGven + _DepoPremium;
                                                            PremiumQven = PremiumQven + (_PrecioPremiumC * _DepoPremium);

                                                        }
                                                        if (Elig == 3) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 3 )
                                                        {

                                                            Bomba3G = Bomba3G + _DepoPremium;
                                                            Bomba3Q = Bomba3Q + (_PrecioPremiumC * _DepoPremium);

                                                            PremiumGven = PremiumGven + _DepoPremium;
                                                            PremiumQven = PremiumQven + (_PrecioPremiumC * _DepoPremium);

                                                        }
                                                        if (Elig == 4) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 4 )
                                                        {

                                                            Bomba4G = Bomba4G + _DepoPremium;
                                                            Bomba4Q = Bomba4Q + (_PrecioPremiumC * _DepoPremium);

                                                            PremiumGven = PremiumGven + _DepoPremium;
                                                            PremiumQven = PremiumQven + (_PrecioPremiumC * _DepoPremium);

                                                        }
                                                        if (Elig == 5) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 5 )
                                                        {

                                                            Bomba5G = Bomba5G + _DepoPremium;
                                                            Bomba5Q = Bomba5Q + (_PrecioPremiumC * _DepoPremium);

                                                            PremiumGven = PremiumGven + _DepoPremium;
                                                            PremiumQven = PremiumQven + (_PrecioPremiumC * _DepoPremium);

                                                        }

                                                        _DepoPremium = 0;

                                                        Console.WriteLine("\n¿Desea seguir comprando combustible? y/n");
                                                        string Res2 = Console.ReadLine().ToLower();

                                                        if (Res2 == "Y".ToLower())
                                                        {

                                                            Continuar2 = false;

                                                        }
                                                        else
                                                        {

                                                            Continuar2 = true;

                                                        }

                                                    }
                                                    else
                                                    {

                                                        Console.WriteLine("\nEntendido, porofavor reingrese una nueva cantidad.");
                                                        Continuar2 = false;

                                                    }

                                                }
                                                else
                                                {

                                                    Console.WriteLine("\n*** Compra Exitosa ***");
                                                    Console.WriteLine("* Su total es de galones es de: " + ((_PrecioPremiumC / _DepoPremium) / (Quiero * _DepoPremium)));

                                                    _DepoPremium = _DepoPremium - ((_PrecioPremiumC / _DepoPremium) / (Quiero * _DepoPremium));
                                                    DeudaDeGasolinera = DeudaDeGasolinera - Quiero;
                                                    GananciasGaso = GananciasGaso + Quiero;

                                                    // Datasos

                                                    if (Elig == 1) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 1 )
                                                    {

                                                        Bomba1G = Bomba1G + ((_PrecioPremiumC / _DepoPremium) / (Quiero * _DepoPremium));
                                                        Bomba1Q = Bomba1Q + Quiero;

                                                        PremiumGven = PremiumGven + ((_PrecioPremiumC / _DepoPremium) / (Quiero * _DepoPremium));
                                                        PremiumQven = PremiumQven + Quiero;

                                                    }
                                                    if (Elig == 2) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 2 )
                                                    {

                                                        Bomba2G = Bomba2G + ((_PrecioPremiumC / _DepoPremium) / (Quiero * _DepoPremium));
                                                        Bomba2Q = Bomba2Q + Quiero;

                                                        PremiumGven = PremiumGven + ((_PrecioPremiumC / _DepoPremium) / (Quiero * _DepoPremium));
                                                        PremiumQven = PremiumQven + Quiero;

                                                    }
                                                    if (Elig == 3) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 3 )
                                                    {

                                                        Bomba3G = Bomba3G + ((_PrecioPremiumC / _DepoPremium) / (Quiero * _DepoPremium));
                                                        Bomba3Q = Bomba3Q + Quiero;

                                                        PremiumGven = PremiumGven + ((_PrecioPremiumC / _DepoPremium) / (Quiero * _DepoPremium));
                                                        PremiumQven = PremiumQven + Quiero;

                                                    }
                                                    if (Elig == 4) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 4 )
                                                    {

                                                        Bomba4G = Bomba4G + ((_PrecioPremiumC / _DepoPremium) / (Quiero * _DepoPremium));
                                                        Bomba4Q = Bomba4Q + Quiero;

                                                        PremiumGven = PremiumGven + ((_PrecioPremiumC / _DepoPremium) / (Quiero * _DepoPremium));
                                                        PremiumQven = PremiumQven + Quiero;

                                                    }
                                                    if (Elig == 5) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 5 )
                                                    {

                                                        Bomba5G = Bomba5G + ((_PrecioPremiumC / _DepoPremium) / (Quiero * _DepoPremium));
                                                        Bomba5Q = Bomba5Q + Quiero;

                                                        PremiumGven = PremiumGven + ((_PrecioPremiumC / _DepoPremium) / (Quiero * _DepoPremium));
                                                        PremiumQven = PremiumQven + Quiero;

                                                    }

                                                    Console.WriteLine("\n¿Desea seguir comprando combustible? y/n");
                                                    string Res2 = Console.ReadLine().ToLower();

                                                    if (Res2 == "Y".ToLower())
                                                    {

                                                        Continuar2 = false;

                                                    }
                                                    else
                                                    {

                                                        Continuar2 = true;

                                                    }

                                                }

                                            }
                                            break;

                                        default:
                                            {

                                                Continuar2 = false;
                                                Console.WriteLine("Porfavor elige una de las opciones dadas ");

                                            }
                                            break;

                                    }

                                }
                                while (Continuar2 == false);

                            }

                            // ---------------------------------------------------------- ( Opcion 2 )

                            else if (Res == 2)
                            {

                                _Continuar = true;

                                Console.WriteLine("\nElegiste: Venta y despacho automático al cliente.");

                                do
                                {

                                    Console.WriteLine("\nTipos de combustible: ");
                                    Console.WriteLine("1. Diesel");
                                    Console.WriteLine("2. Regular");
                                    Console.WriteLine("3. Super");
                                    Console.WriteLine("4. Premium");

                                    Console.WriteLine("\nElige el numero del combustible deseas");
                                    double TDC = double.Parse(Console.ReadLine());

                                    switch (TDC)
                                    {

                                        case 1:
                                            {
                                                Continuar2 = true;

                                                Console.WriteLine("\nElegiste combustible: Diesel");
                                                Console.WriteLine("*** Compra Exitosa ***");
                                                Console.WriteLine("Su candiad adquirida fue de Q. 20.00");

                                                _DepoDiesel = _DepoDiesel - ((20 * _DepoDiesel) / (_PrecioDieselC * _DepoDiesel));
                                                DeudaDeGasolinera = DeudaDeGasolinera - 20;
                                                GananciasGaso = GananciasGaso + 20;

                                                // Datasos

                                                if (Elig == 1) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 1 )
                                                {

                                                    Bomba1G = Bomba1G + ((_PrecioDieselC * _DepoDiesel) / 20);
                                                    Bomba1Q = Bomba1Q + 20;

                                                    DieselGven = DieselGven + ((_PrecioDieselC * _DepoDiesel) / 20);
                                                    DieselQven = DieselQven + 20;


                                                } 
                                                if (Elig == 2) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 2 )
                                                {

                                                    Bomba2G = Bomba2G + ((_PrecioDieselC * _DepoDiesel) / 20);
                                                    Bomba2Q = Bomba2Q + 20;

                                                    DieselGven = DieselGven + ((_PrecioDieselC * _DepoDiesel) / 20);
                                                    DieselQven = DieselQven + 20;

                                                }
                                                if (Elig == 3) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 3 )
                                                {

                                                    Bomba3G = Bomba3G + ((_PrecioDieselC * _DepoDiesel) / 20);
                                                    Bomba3Q = Bomba3Q + 20;

                                                    DieselGven = DieselGven + ((_PrecioDieselC * _DepoDiesel) / 20);
                                                    DieselQven = DieselQven + 20;

                                                }
                                                if (Elig == 4) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 4 )
                                                {

                                                    Bomba4G = Bomba4G + ((_PrecioDieselC * _DepoDiesel) / 20);
                                                    Bomba4Q = Bomba4Q + 20;

                                                    DieselGven = DieselGven + ((_PrecioDieselC * _DepoDiesel) / 20);
                                                    DieselQven = DieselQven + 20;

                                                }
                                                if (Elig == 5) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 5 )
                                                {

                                                    Bomba5G = Bomba5G + ((_PrecioDieselC * _DepoDiesel) / 20);
                                                    Bomba5Q = Bomba5Q + 20;

                                                    DieselGven = DieselGven + ((_PrecioDieselC * _DepoDiesel) / 20);
                                                    DieselQven = DieselQven + 20;

                                                }

                                                Console.WriteLine("\n¿Desea seguir comprando combustible? y/n");
                                                string Res2 = Console.ReadLine().ToLower();

                                                if (Res2 == "Y".ToLower())
                                                {

                                                    Continuar2 = false;

                                                }
                                                else
                                                {

                                                    Continuar2 = true;

                                                }

                                            }
                                            break;

                                        case 2:
                                            {

                                                Continuar2 = true;

                                                Console.WriteLine("\nElegiste combustible: Regular");
                                                Console.WriteLine("*** Compra Exitosa ***");
                                                Console.WriteLine("Su candiad adquirida fue de Q. 20.00");

                                                _DepoRegular = _DepoRegular - ((20 * _DepoRegular) / (_PrecioRegularC * _DepoRegular));
                                                DeudaDeGasolinera = DeudaDeGasolinera - 20;
                                                GananciasGaso = GananciasGaso + 20;

                                                // Datasos

                                                if (Elig == 1) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 1 )
                                                {

                                                    Bomba1G = Bomba1G + ((_PrecioRegularC * _DepoRegular) / 20);
                                                    Bomba1Q = Bomba1Q + 20;

                                                    RegularGven = RegularGven + ((_PrecioRegularC * _DepoRegular) / 20);
                                                    RegularQven = RegularQven + 20;

                                                }
                                                if (Elig == 2) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 2 )
                                                {

                                                    Bomba2G = Bomba2G + ((_PrecioRegularC * _DepoRegular) / 20);
                                                    Bomba2Q = Bomba2Q + 20;

                                                    RegularGven = RegularGven + ((_PrecioRegularC * _DepoRegular) / 20);
                                                    RegularQven = RegularQven + 20;

                                                }
                                                if (Elig == 3) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 3 )
                                                {

                                                    Bomba3G = Bomba3G + ((_PrecioRegularC * _DepoRegular) / 20);
                                                    Bomba3Q = Bomba3Q + 20;

                                                    RegularGven = RegularGven + ((_PrecioRegularC * _DepoRegular) / 20);
                                                    RegularQven = RegularQven + 20;

                                                }
                                                if (Elig == 4) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 4 )
                                                {

                                                    Bomba4G = Bomba4G + ((_PrecioRegularC * _DepoRegular) / 20);
                                                    Bomba4Q = Bomba4Q + 20;

                                                    RegularGven = RegularGven + ((_PrecioRegularC * _DepoRegular) / 20);
                                                    RegularQven = RegularQven + 20;

                                                }
                                                if (Elig == 5) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 5 )
                                                {

                                                    Bomba5G = Bomba5G + ((_PrecioRegularC * _DepoRegular) / 20);
                                                    Bomba5Q = Bomba5Q + 20;

                                                    RegularGven = RegularGven + ((_PrecioRegularC * _DepoRegular) / 20);
                                                    RegularQven = RegularQven + 20;

                                                }

                                                Console.WriteLine("\n¿Desea seguir comprando combustible? y/n");
                                                string Res2 = Console.ReadLine().ToLower();

                                                if (Res2 == "Y".ToLower())
                                                {

                                                    Continuar2 = false;

                                                }
                                                else
                                                {

                                                    Continuar2 = true;

                                                }

                                            }
                                            break;

                                        case 3:
                                            {

                                                Continuar2 = true;

                                                Console.WriteLine("\nElegiste combustible: Super");
                                                Console.WriteLine("*** Compra Exitosa ***");
                                                Console.WriteLine("Su candiad adquirida fue de Q. 20.00");

                                                _DepoSuper = _DepoSuper - ((20 * _DepoSuper) / (_PrecioSuperC * _DepoSuper));
                                                DeudaDeGasolinera = DeudaDeGasolinera - 20;
                                                GananciasGaso = GananciasGaso + 20;

                                                // Datasos

                                                if (Elig == 1) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 1 )
                                                {

                                                    Bomba1G = Bomba1G + ((_PrecioSuperC * _DepoSuper) / 20);
                                                    Bomba1Q = Bomba1Q + 20;

                                                    SuperGven = SuperGven + ((_PrecioSuperC * _DepoSuper) / 20);
                                                    SuperQven = SuperQven + 20;

                                                }
                                                if (Elig == 2) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 2 )
                                                {

                                                    Bomba2G = Bomba2G + ((_PrecioSuperC * _DepoSuper) / 20);
                                                    Bomba2Q = Bomba2Q + 20;

                                                    SuperGven = SuperGven + ((_PrecioSuperC * _DepoSuper) / 20);
                                                    SuperQven = SuperQven + 20;

                                                }
                                                if (Elig == 3) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 3 )
                                                {

                                                    Bomba3G = Bomba3G + ((_PrecioSuperC * _DepoSuper) / 20);
                                                    Bomba3Q = Bomba3Q + 20;

                                                    SuperGven = SuperGven + ((_PrecioSuperC * _DepoSuper) / 20);
                                                    SuperQven = SuperQven + 20;

                                                }
                                                if (Elig == 4) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 4 )
                                                {

                                                    Bomba4G = Bomba4G + ((_PrecioSuperC * _DepoSuper) / 20);
                                                    Bomba4Q = Bomba4Q + 20;

                                                    SuperGven = SuperGven + ((_PrecioSuperC * _DepoSuper) / 20);
                                                    SuperQven = SuperQven + 20;

                                                }
                                                if (Elig == 5) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 5 )
                                                {

                                                    Bomba5G = Bomba5G + ((_PrecioSuperC * _DepoSuper) / 20);
                                                    Bomba5Q = Bomba5Q + 20;

                                                    SuperGven = SuperGven + ((_PrecioSuperC * _DepoSuper) / 20);
                                                    SuperQven = SuperQven + 20;

                                                }

                                                Console.WriteLine("\n¿Desea seguir comprando combustible? y/n");
                                                string Res2 = Console.ReadLine().ToLower();

                                                if (Res2 == "Y".ToLower())
                                                {

                                                    Continuar2 = false;

                                                }
                                                else
                                                {

                                                    Continuar2 = true;

                                                }

                                            }
                                            break;

                                        case 4:
                                            {

                                                Continuar2 = true;

                                                Console.WriteLine("\nElegiste combustible: Premium");
                                                Console.WriteLine("*** Compra Exitosa ***");
                                                Console.WriteLine("Su candiad adquirida fue de Q. 20.00");

                                                _DepoPremium = _DepoPremium - ((20 * _DepoPremium) / (_PrecioPremiumC * _DepoPremium));
                                                DeudaDeGasolinera = DeudaDeGasolinera - 20;
                                                GananciasGaso = GananciasGaso + 20;

                                                // Datasos

                                                if (Elig == 1) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 1 )
                                                {

                                                    Bomba1G = Bomba1G + ((_PrecioPremiumC * _DepoPremium) / 20);
                                                    Bomba1Q = Bomba1Q + 20;

                                                    PremiumGven = PremiumGven + ((_PrecioPremiumC * _DepoPremium) / 20);
                                                    PremiumQven = PremiumQven + 20;

                                                }
                                                if (Elig == 2) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 2 )
                                                {

                                                    Bomba2G = Bomba2G + ((_PrecioPremiumC * _DepoPremium) / 20);
                                                    Bomba2Q = Bomba2Q + 20;

                                                    PremiumGven = PremiumGven + ((_PrecioPremiumC * _DepoPremium) / 20);
                                                    PremiumQven = PremiumQven + 20;

                                                }
                                                if (Elig == 3) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 3 )
                                                {

                                                    Bomba3G = Bomba3G + ((_PrecioPremiumC * _DepoPremium) / 20);
                                                    Bomba3Q = Bomba3Q + 20;

                                                    PremiumGven = PremiumGven + ((_PrecioPremiumC * _DepoPremium) / 20);
                                                    PremiumQven = PremiumQven + 20;

                                                }
                                                if (Elig == 4) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 4 )
                                                {

                                                    Bomba4G = Bomba4G + ((_PrecioPremiumC * _DepoPremium) / 20);
                                                    Bomba4Q = Bomba4Q + 20;

                                                    PremiumGven = PremiumGven + ((_PrecioPremiumC * _DepoPremium) / 20);
                                                    PremiumQven = PremiumQven + 20;

                                                }
                                                if (Elig == 5) // ----------------------------------------------------------------------------------------------------------------- ( Bomba 5 )
                                                {

                                                    Bomba5G = Bomba5G + ((_PrecioPremiumC * _DepoPremium) / 20);
                                                    Bomba5Q = Bomba5Q + 20;

                                                    PremiumGven = PremiumGven + ((_PrecioPremiumC * _DepoPremium) / 20);
                                                    PremiumQven = PremiumQven + 20;

                                                }

                                                Console.WriteLine("\n¿Desea seguir comprando combustible? y/n");
                                                string Res2 = Console.ReadLine().ToLower();

                                                if (Res2 == "Y".ToLower())
                                                {

                                                    Continuar2 = false;

                                                }
                                                else
                                                {

                                                    Continuar2 = true;

                                                }

                                            }
                                            break;

                                        default:
                                            {

                                                Continuar2 = false;
                                                Console.WriteLine("Porfavor elige una de las opciones dadas ");

                                            }
                                            break;

                                    }

                                }
                                while (Continuar2 == false);
                            }
                            else
                            {

                                _Continuar = false;
                                Console.WriteLine("\nPorfavor Ingrese uno de las opciones dadas");

                            }

                        }
                        while (_Continuar == false);

                    }

                }

                // ----------------------------------------------------------------------------------------------------------------- ( Default )

                else
                {

                    Continuar = false;
                    Console.WriteLine("\nPorfavor elige una de las opciones dadas ");

                }
                break;

            }
            while (Continuar == false);

        }




















        //--------------------------------------------------------------------------------------------------------------------------------------------------------------
        //--------------------------------------------------------------------------------------------------------------------------------------------------------------
        //--------------------------------------------------------------------------------------------------------------------------------------------------------------

        // ((((((((((((((( OBJETOS 4 )))))))))))))))

        public void DatosGenerales()
        {

            // Total de galones y quetzales vendidos por cada bomba. 

            double
            _DiecelQCash = _DiecelQ * _PrecioDiesel,
            _RegularQCash = _RegularQ * _PrecioRegular,
            _SuperQCash = _SuperQ * _PrecioSuper,
            _PremiumQCash = _PremiumQ * _PrecioPremium;

            Console.WriteLine("\nTotal de galones y quetzales vendidos por cada bomba. ");
            Console.WriteLine("* Bomba 1: " + Bomba1G + " Galones y Q. " + Bomba1Q);
            Console.WriteLine("* Bomba 2: " + Bomba2G + " Galones y Q. " + Bomba2Q);
            Console.WriteLine("* Bomba 2: " + Bomba3G + " Galones y Q. " + Bomba3Q);
            Console.WriteLine("* Bomba 3: " + Bomba4G + " Galones y Q. " + Bomba4Q);
            Console.WriteLine("* Bomba 4: " + Bomba5G + " Galones y Q. " + Bomba5Q);
            Console.WriteLine("* Total: " + (Bomba1G + Bomba2G + Bomba3G + Bomba4G + Bomba5G) + " Galones y Q. " + (Bomba1Q + Bomba2Q + Bomba3Q + Bomba4Q + Bomba5Q));

            // Total de galones y quetzales vendidos para cada tipo de combustible.

            Console.WriteLine("\nTotal de galones y quetzales vendidos para cada tipo de combustible.");
            Console.WriteLine("* Diesel: " + DieselGven + " Galones y Q. " + DieselQven);
            Console.WriteLine("* Regular: " + RegularGven + " Galones y Q. " + RegularQven);
            Console.WriteLine("* Super: " + SuperGven + " Galones y Q. " + SuperQven);
            Console.WriteLine("* Premium: " + PremiumGven + " Galones y Q. " + PremiumQven);
            Console.WriteLine("* Total: " + (DieselGven + RegularGven + SuperGven + PremiumGven) + " Galones y Q. " + (DieselQven + RegularQven + SuperQven + PremiumQven));

            // Total de galones y quetzales comprados para cada tipo de combustible.

            Console.WriteLine("\nTotal de galones y quetzales comprados para cada tipo de combustible. ");
            Console.WriteLine("* Diesel: " + _DiecelQ + " Galones y Q. " + _DiecelQCash);
            Console.WriteLine("* Regular: " + _RegularQ + " Galones y Q. " + _RegularQCash);
            Console.WriteLine("* Super: " + _SuperQ + " Galones y Q. " + _SuperQCash);
            Console.WriteLine("* Premium: " + _PremiumQ + " Galones y Q. " + _PremiumQCash);
            Console.WriteLine("* Total: " + (_DiecelQ + _RegularQ + _SuperQ + _PremiumQCash) + " Galones y Q. " + (_DiecelQCash + _RegularQCash + _SuperQCash + _PremiumQCash));

            // Ganancia total de la gasolinera.

            Console.WriteLine("\nGanancia total de la gasolinera. ");
            Console.WriteLine("* " + GananciasGaso);

            // Deuda total de la gasolinera.

            Console.WriteLine("\nDeuda total de la gasolinera. ");
            Console.WriteLine("* " + DeudaDeGasolinera);





















            //--------------------------------------------------------------------------------------------------------------------------------------------------------------
            //--------------------------------------------------------------------------------------------------------------------------------------------------------------
            //--------------------------------------------------------------------------------------------------------------------------------------------------------------

            // ((((((((((((((( OBJETOS 5 )))))))))))))))



        }

    }

}
